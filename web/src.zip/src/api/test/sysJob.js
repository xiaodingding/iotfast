import request from '@/utils/request'
// 查询定时任务调度列表
export function listSysJob(query) {
  return request({
    url: '/test/sysJob/list',
    method: 'get',
    params: query
  })
}
// 查询定时任务调度详细
export function getSysJob(jobId) {
  return request({
    url: '/test/sysJob/get',
    method: 'get',
    params: {
     id: jobId.toString()
    }
  })
}
// 新增定时任务调度
export function addSysJob(data) {
  return request({
    url: '/test/sysJob/add',
    method: 'post',
    data: data
  })
}
// 修改定时任务调度
export function updateSysJob(data) {
  return request({
    url: '/test/sysJob/edit',
    method: 'put',
    data: data
  })
}
// 删除定时任务调度
export function delSysJob(jobIds) {
  return request({
    url: '/test/sysJob/delete',
    method: 'delete',
    data:{
       ids:jobIds
    }
  })
}
// 定时任务调度状态（0正常 1暂停）修改
export function changeSysJobStatus(jobId,status) {
  const data = {
    jobId,
    status
  }
  return request({
    url: '/test/sysJob/changeStatus',
    method: 'put',
    data:data
  })
}
