import Cookies from 'js-cookie';
import { defineStore } from 'pinia';
import { UserInfosState,UserInfosStates } from './interface';
import { Session } from '/@/utils/storage';

/**
 * 用户信息
 * @methods setUserInfos 设置用户信息
 */
export const useUserInfo = defineStore('userInfo', {
	state: (): UserInfosStates => ({
		userInfos: {
			id:0,
			userNickname:'',
			userName: '',
			avatar: '',
			time: 0,
			roles: [],
			authBtnList: [],
		},
		permissions:[]
	}
	),
	actions: {
		async setBackUserInfos(userInfos: UserInfosState)
		{
			if (userInfos) {
				this.userInfos = userInfos;
			} else {
				if (Session.get('userInfo')){
					this.userInfos = Session.get('userInfo');
				}
			}
		},
		async setPermissions(data: string[])
		{
			if (data) {
				//commit('getPermissions', data);
				this.permissions = data;
			} else {
				if (Session.get('permissions')){
					this.permissions = Session.get('permissions');
					//commit('getPermissions', Session.get('permissions'));
				}
			}
		},

		async updateUserInfos()
		{
			if (Session.get('permissions')){
				this.permissions = Session.get('permissions');
			}
			
			if (Session.get('userInfo')){
				this.userInfos = Session.get('userInfo');
			}
		},
		async setUserInfos() {
			// 模拟数据，请求接口时，记得删除多余代码及对应依赖的引入
			const userName = Cookies.get('userName');
			// 模拟数据
			let defaultRoles: Array<string> = [];
			let defaultAuthBtnList: Array<string> = [];
			// admin 页面权限标识，对应路由 meta.roles，用于控制路由的显示/隐藏
			let adminRoles: Array<string> = ['admin'];
			// admin 按钮权限标识
			let adminAuthBtnList: Array<string> = ['btn.add', 'btn.del', 'btn.edit', 'btn.link'];
			// test 页面权限标识，对应路由 meta.roles，用于控制路由的显示/隐藏
			let testRoles: Array<string> = ['common'];
			// test 按钮权限标识
			let testAuthBtnList: Array<string> = ['btn.add', 'btn.link'];
			// 不同用户模拟不同的用户权限
			if (userName === 'admin') {
				defaultRoles = adminRoles;
				defaultAuthBtnList = adminAuthBtnList;
			} else {
				defaultRoles = testRoles;
				defaultAuthBtnList = testAuthBtnList;
			}
			// 用户信息模拟数据
			const userInfos = {
				id:0,
				userName: userName,
				userNickname:userName,
				avatar:
					userName === 'admin'
						? 'https://ss0.bdstatic.com/70cFvHSh_Q1YnxGkpoWK1HF6hhy/it/u=1813762643,1914315241&fm=26&gp=0.jpg'
						: 'https://ss1.bdstatic.com/70cFuXSh_Q1YnxGkpoWK1HF6hhy/it/u=317673774,2961727727&fm=26&gp=0.jpg',
				time: new Date().getTime(),
				roles: defaultRoles,
				authBtnList: defaultAuthBtnList,
			};
			// 存储用户信息到浏览器缓存
			Session.set('userInfo', userInfos);

			if (Session.get('userInfo')) {
				this.userInfos = Session.get('userInfo');
			} else {
				this.userInfos = userInfos;
			}
		},
	},
});
